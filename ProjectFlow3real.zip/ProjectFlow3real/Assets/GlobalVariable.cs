﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GlobalVariable{
public static int points = 0;
	// Use this for initializatio
}
